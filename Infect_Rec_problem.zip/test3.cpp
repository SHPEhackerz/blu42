#include <iostream>
#include <fstream>
#include <sstream>
#include <cstring>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <cmath>
#include <algorithm>
#include <iomanip>

using namespace std;

//vital function takes string turns it into character
//double vector that can be used for integers,
//not usual character vector
vector<vector<char>  > stm(string a,int l, int il){
   vector<vector<char>  > In(il,vector<char>(il));
   int i=0,e=0,r=0;
while(i<l){
  //erase newlines and nulls
  if((int)a[i]==0 || (int)a[i]==10){a.erase(i,1);}
  In[e][r]=a[i]; i++;
if(i%il==0){e++;} if(r%il==0){r=0;} r++;}cout<<endl;
return In;}

int main(){
string config_file; //name of configuration file (user input)
	string pop,reg;//name of population file
  int A,P,R,Vac;
	string tmp; //tmp for reading a substring
	char tmpc; //tmpc for reading a substring

	cout << "Please enter the name of the configuration file:";
	cin >> config_file;

	//read initial state
	ifstream infile; //config file stream
	infile.open(config_file); //open configuration file
	
  //check if stream opened config file
	if(infile.fail()){cout << "Error opening file!\n"; exit(1);}
	
  getline(infile,tmp,':') >> pop; //get layout file name
  getline(infile,tmp,':') >> reg;
  
  ifstream inpop; //population file stream
	inpop.open(pop); //open the stream
	
  vector<int> popvector1; vector<int>popvector2;
  string count;int cnt, value;

  while(getline(inpop,count,':')>>value){
  cnt=stoi(count);
  popvector1.push_back(cnt); popvector2.push_back(value);
  }
  cout<<"Regional Population"<<endl;
 for(int i=0;i<popvector2.size();i++){
 cout<<popvector1.at(i)<<" "; cout<<popvector2.at(i)<<endl;
 }
  ifstream region; //region file stream
	region.open(reg); //open the stream
  
  int rli= popvector1.size();
  cout<<endl<<"Adjacency List";

  	string b,l;
  if(region.is_open()){
   string a;
   while(region.good()){ getline(region,a,',');// cout<<a<<" ";
    b+=a; }
}

vector<vector<char>> V;
int il=0; il=b.find('\n');
int bl=pow(il,2);
V=stm(b,bl,il);

int i=0,e=0,r=0;
/*while(i<bl){ 
 cout<<V[e][r];//display adj matrix
i++; if(i%il==0){e++;cout<<endl;} if(r%il==0){r=0;} r++;}cout<<endl;
*/
vector<vector<int> > adjlist;//the adjlist

e=1; //the following code stores the...
     //...values into the adjlist from the matrix
  while(e<il){
   vector<int> listrow;
char is='a';
i=0;
r=0;
while(i<il){ 
  is=V[e][r];
  if(is=='1'){listrow.push_back(r);}
r++; i++; }
  cout<<e<<": ";
  adjlist.push_back(listrow);
  for(int pos=0;pos<listrow.size();pos++){
  cout<<listrow.at(pos)<<" ";}cout<<endl;
   e++;
}
  /* ///This is the output for the adj list
  cout<<endl; cout<<endl; 
  for(int i = 0; i < adjlist.size(); i++){
		for(int j = 0; j < adjlist[i].size(); j++){
      cout << adjlist[i][j] << " ";
     // cout<<"i: "<<i<<" j:"<<j <<endl;
    }
    cout<<endl;
	}*/

  cout<<endl;
  getline(infile,tmp,':') >> A;
  getline(infile,tmp,':') >> P;
  getline(infile,tmp,':') >> R;
  getline(infile,tmp,':') >> Vac;
  
//cout<<pop<<"  "<<reg<<"  "<<A<<"  "<<P<<"  "<<R<<"  "<<Vac<<endl;
///pop=pop.txt, reg=region.csv, A=infected area
///P=infectious period, R=contact rate, Vac=#of vaccines

/// Now to start part 2
cout<<"CLOSENESS DISTRIBUTION"<<endl;
  int day=0,I=1,rec=0; bool infect=true;
  vector<int> infectv;
  vector<int> hist;
  vector<int> recovered;
 // cout<<"good"<<endl; //seg fault check
  for(int i=0;i<popvector1.size();i++){
infectv.push_back(0);
  }
   for(int i=0;i<popvector1.size();i++){
recovered.push_back(0);
  }
 // cout<<"better"<<endl;//seg fault check
  
  while(infect){
    int Icnt=0;
  cout<<"Day "<<day<<endl;
    if(I<popvector2.at(A-1)/2){
    infectv.at(A-1)=I;}
    else{
      for(int i=0;i<adjlist[A-1].size();i++){
      infectv.at(adjlist[A-1][i])=I;
      }
    }
  for(int i=0;i<popvector2.size();i++){
     //display and formatting for each day
    cout<<setw(2);
    cout<< popvector1.at(i);
    cout<<setw(8);
    cout<< "POP:";
    cout<<setw(6);
    cout<< popvector2.at(i);
    cout<<setw(5);
    cout<<"S: ";
    cout<<setw(4);
    cout<<"____";
    cout<<setw(5);
    cout<<"I: ";
    cout<<setw(4);
    cout<<infectv.at(i);
    cout<<setw(5);
    cout<<"R: ";
    cout<<setw(4);
    cout<<recovered.at(i);
    cout<<setw(5);
    cout<<"V: ";
    cout<<setw(4);
    cout<<"____"<<endl;

  for(int i=0;i<infectv.size();i++){
  if(infectv.at(i)==0){//sentinel condition
Icnt++;} }
   if(Icnt==9){infect=false;}
   }
    day++;
    hist.push_back(I);
    I=(I*R)+I;
        if(day%P==0){ }
    /*
    if(day%P==0){
I=I-hist.at(rec); 
 recovered.at(A-1)=hist.at(rec);}
    */
    rec++;
    //function that manages
    //infection values goes here

    
if(day>6){break;}//plse comment this out
    //after you get good results its here
    //so theres not an infinite while
    //kinda like training wheels
  }
  return 0;
}
