Group Members:
	Jesus T. Patino
	Humberto Brito
	Madison Hardage
	Jacob Kariampally

Methods:
---------------------------------
To Compile: g++ test3.cpp
	to run: ./a.out
----------------------------